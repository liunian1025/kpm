# KernelPatch Module
