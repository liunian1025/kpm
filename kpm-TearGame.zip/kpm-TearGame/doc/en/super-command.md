# Super Command

truncate SUPERKEY help
