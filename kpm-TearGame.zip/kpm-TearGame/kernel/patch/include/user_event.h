/* SPDX-License-Identifier: GPL-2.0-or-later */
/* 
 * Copyright (C) 2024 bmax121. All Rights Reserved.
 */

#ifndef _KP_USER_EVENT_H_
#define _KP_USER_EVENT_H_

int report_user_event(const char *event, const char *args);

#endif