#ifndef _LINUX_INIT_TASK_H
#define _LINUX_INIT_TASK_H

extern struct task_struct *init_task;
extern const struct cred *init_cred;

#endif