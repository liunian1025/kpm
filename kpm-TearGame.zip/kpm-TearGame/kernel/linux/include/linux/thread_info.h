#ifndef _LINUX_THREAD_INFO_H
#define _LINUX_THREAD_INFO_H

#include <asm/current.h>
#include <asm/thread_info.h>

#endif