#ifndef _LINUX_KALLSYMS_H
#define _LINUX_KALLSYMS_H

#include <kallsyms.h>

#endif