#ifndef __ASM_IO_H
#define __ASM_IO_H

#include <io.h>

#endif