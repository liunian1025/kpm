/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _TOOLS_LINUX_ASM_AARCH64_BARRIER_H
#define _TOOLS_LINUX_ASM_AARCH64_BARRIER_H

#include <barrier.h>

#endif /* _TOOLS_LINUX_ASM_AARCH64_BARRIER_H */