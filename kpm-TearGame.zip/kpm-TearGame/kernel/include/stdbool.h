#ifndef _KP_STDBOOL_H_
#define _KP_STDBOOL_H_

#ifndef __bool_true_false_are_defined

#define bool _Bool
#define true 1
#define false 0

#endif

#endif