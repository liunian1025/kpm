---
name: 'Bug: Can''t boot'
about: Unable to boot after flashing the new boot.img
title: ''
labels: ''
assignees: ''

---

**Currently, there is no immediate solution. You need to troubleshoot it yourself or provide the device to me for further investigation.**
