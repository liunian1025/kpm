/* SPDX-License-Identifier: GPL-2.0-or-later */
/* 
 * Copyright (C) 2023 bmax121. All Rights Reserved.
 */

#ifndef _KPU_ANDROID_USER_H_
#define _KPU_ANDROID_USER_H_

#ifdef __cplusplus
extern "C"
{
#endif

    int android_user(int argc, char **argv);

#ifdef __cplusplus
}
#endif

#endif